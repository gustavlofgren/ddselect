(function($, undefined) {
    
    /* TO DO
        * overhaul the entire plugin to make searching through long lists faster
        * iron out kinks with keyboard navigation
        * additional options for the user, such as plugin behavior and style
        * behavior when resizing the browser while the dropdown is open
    */
    
        jQuery.expr[':'].icontains = function(a, i, m) {
          return jQuery(a).text().toUpperCase()
              .indexOf(m[3].toUpperCase()) >= 0;
        };
        $.widget("custom.ddselect", {
            // default options
            
            options: {
                buttontext: '<img src="img/caret.png" style="height: 10px">',
                isOpen: false,
                noresult: 'No results',
                placeholder: 'Enter a searchterm...',
                width: '100%',
                resultsheight: '400px',
                // callbacks
                change: null
            },
            
            // the constructor
            _create: function() {
                var $select = this.element;
                    
                ddmenu = this._createDdMenu(),
                this.ddmenu = $(ddmenu);
            
                $select.hide();
                // cache commonly used elements
                this._cacheElements();
                // bind UI actions
                this._bindUIActions();
                
                // append the created combobox to the page
                $select.after(this.ddmenu);
                this._setOptions();
                this._setOption();
                this._refresh();
                
            },
        
            // called when created, and later when changing options
            _refresh: function() {
            },
        
            // events bound via _on are removed automatically
            // revert other modifications here
            destroy: function() {
                this.ddmenu.remove();
                this.element.show();
            },
        
            _createListItems: function(options) {
                var lis = [];
                function createListItem(val, text) {
                    return '\t<li data-value="' + val + '">' + '<span data-value="' + val + '">' + text + '</span>' + '</li>\n';
                }
        
                $.each( options, function(key, option) {
                    var $option = $(option),
                        li = createListItem($option.val(),
                        $option.text());
                    lis.push(li);
                });
                return lis.join('');
            },
            
            _createDdMenu: function() {
                var $select = this.element,
                    opts = this.options,
                    ddselect = '';
                    
                //generate markup for the widget
                ddselect += '\t<div class="dd-nav">\n';
                ddselect += '\t\t<input type="text" placeholder="' + opts.placeholder + '" class="dd-txt"/>\n';
                ddselect += '\t\t<a class="dd-btn">' + opts.buttontext + '</a>\n'; 
                ddselect += '\t</div>\n';
                ddselect += '\t<ul class="dd-options">\n';  
                //loop through select element and grab options and turn them into list items
                ddselect += this._createListItems($select.children('option'));
                ddselect += '\t<a class="dd-no-result">' + opts.noresult + '</a>\n';
                ddselect += '\t</ul>';
                return ddselect;
                    
            },
            
            _openClose: function(e) {
                var $textbox = this.cached['.dd-txt'],
                    $this = $('.dd-nav'),
                    $list = this.cached['.dd-options'];
                    
                if ($list.is(':hidden')) {
                    $list.show();
                    $textbox.focus();
                    this.cached['.dd-options'].width(this.ddmenu.width());
                    //$('.dd-nav').next()
                    //        .width($('.dd-nav')
                    //        .width());
                } else if ($list.is(':visible')) {
                    $list.hide();
                    $textbox.blur();
                }
            },
          
            _selectListItem: function(e) {
                var $selectedLi = $(e.target),
                    selectedValue = $selectedLi.data('value'),
                    $select = this.element;
                
                this.cached['.dd-txt'].val(selectedValue);
                this._openClose();
                $select.val(selectedValue);
            },
        
            _autocomplete: function (e) {
                var searchfield = this.cached['.dd-txt'].val(),
                    $results = null,
                    $list = this.cached['.dd-options li'],
                    $select = this.element,
                    opts = this.options;
               
                if (searchfield !== '') { 
                    $results = this.cached['.dd-options li'].children('span:icontains(' + searchfield + ')');
                }
                if ($results) {
                   
                    var $spans = this.cached['.dd-options li'].children().not($results);
                    this.cached['.dd-options'].show();
                    this.cached['.dd-options li'].show();
                    this.cached['.dd-options li'].children().show();
                    $spans.parent().hide();
                    $spans.hide();
               
                    if (this.cached['.dd-options'].children('li:visible').length === 0){
                        this.cached['.dd-options'].children('.dd-no-result').show();
                    } else if (this.cached['.dd-options'].children('li:visible').length >= 1) {
                        this.cached['.dd-options'].children('.dd-no-result').hide();
                    }
               
                } else {
                    this.cached['.dd-options'].hide();
                    this.cached['.dd-options li'].show();
                    this.cached['.dd-options li'].children().show();
                    $('.dd-no-result').hide(); 
                    }
            },
        
            _bindUIActions: function() {
                
                this._on(this.document, {
                    click: function(e){
                        if(!$(e.target).closest(this.ddmenu).length){
                            this.cached['.dd-options'].hide();
                        } 
                    }
                });

                this.cached['.dd-options'].hide();
                if (this.options.isOpen) {
                  this.cached['.dd-options'].show();
                }
                this._on(this.cached['.dd-btn'], {
                    click: '_openClose',  
                });
                this._on(this.cached['.dd-options li'], {
                    click: '_selectListItem'    
                });
                this._on(this.cached['.dd-txt'], {
                    keyup: '_autocomplete',    
                });     
            },
        
            val: function(){
                return this.element.children(':selected').val();
            },
        
            text: function(){
                return this.element.children(':selected').text();
            },
        
            _setOptions: function() {
                
                // _super and _superApply handle keeping the right this-context
                this._superApply( arguments );
                this._refresh();
            },
        
            _setOption: function(key, value) {
                this._super(key, value);
                var opts = this.options;
                this.ddmenu.css('max-width', opts.width);
                this.cached['.dd-options'].width(this.ddmenu.width());
                this.cached['.dd-options'].css('max-height', opts.resultsheight);
                
                
            },
            _cacheElements: function() {
                var $ddmenu = this.ddmenu,
                    $ddnav = $ddmenu.find('.dd-nav'),
                    $ddmenubtn = $ddmenu.find('.dd-btn'),
                    $ddmenutxt = $ddmenu.find('.dd-txt'),
                    $options = $ddmenu.siblings('.dd-options'),
                    $listitems = $options.children(); 
                this.cached = {
                    ".dd-btn": $ddmenubtn,
                    ".dd-options": $options,
                    ".dd-options li": $listitems,
                    ".dd-nav": $ddnav,
                    ".dd-txt": $ddmenutxt
                };
            },
        });//$widget
}(jQuery));
